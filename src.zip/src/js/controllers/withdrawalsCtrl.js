angular.module('yyzWebApp')
    .controller('withdrawalsCtrl', ['$scope', '$http', function ($scope, $http) {
        $scope.accoutView = false;
    }]);