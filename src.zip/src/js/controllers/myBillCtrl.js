angular.module('yyzWebApp')
    .controller('myBillCtrl', ['$scope', function ($scope) {
    }]);