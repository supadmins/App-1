angular.module('yyzWebApp')
    .controller('goodsTypeHelperCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);