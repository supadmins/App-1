angular.module('yyzWebApp')
    .controller('shopInfoCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);