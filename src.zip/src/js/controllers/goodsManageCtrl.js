angular.module('yyzWebApp')
    .controller('goodsManageCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);