angular.module('yyzWebApp')
    .controller('goodsTypeManageCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);