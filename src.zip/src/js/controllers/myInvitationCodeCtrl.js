angular.module('yyzWebApp')
    .controller('myInvitationCodeCtrl', ['$scope', function ($scope) {
    }]);
