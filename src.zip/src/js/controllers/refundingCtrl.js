angular.module('yyzWebApp')
    .controller('refundingCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);