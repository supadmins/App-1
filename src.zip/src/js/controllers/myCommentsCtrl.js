angular.module('yyzWebApp')
    .controller('myCommentsCtrl', ['$scope', function ($scope) {
    }]);
