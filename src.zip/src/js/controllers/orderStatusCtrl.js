angular.module('yyzWebApp')
    .controller('orderStatusCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);