angular.module('yyzWebApp')
    .controller('addEvaluateCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);