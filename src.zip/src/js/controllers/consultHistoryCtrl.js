angular.module('yyzWebApp')
    .controller('consultHistoryCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);