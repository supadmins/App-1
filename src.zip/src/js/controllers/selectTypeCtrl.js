angular.module('yyzWebApp')
    .controller('selectTypeCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);