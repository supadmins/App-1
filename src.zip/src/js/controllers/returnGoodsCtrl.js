angular.module('yyzWebApp')
    .controller('returnGoodsCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);