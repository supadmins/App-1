angular.module('yyzWebApp')
    .controller('createOrderCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);