angular.module('yyzWebApp')
    .controller('orderRefundListCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);