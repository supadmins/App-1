angular.module('yyzWebApp')
    .controller('roleCtrl', ['$scope', '$http', function ($scope, $http) {
    }]);